from listaPokemon import *
from pokemon_db import *
from escolher import *
from batalha import batalhar

# Função principal
def main():
    decisao()
    batalhar()
    escolher_pokemon()
    
    
if __name__ == '__main__':
    main()

