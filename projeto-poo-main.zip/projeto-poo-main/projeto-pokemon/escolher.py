import os
from batalha import batalhar
from pokemon_db import *
from listaPokemon import *



def fugir():
    limpar_tela()
    print('Você fugiu!')
    exit()

def limpar_tela():
    os.system('cls')


def decisao():
    try:
        limpar_tela()
        print('𝚅𝚘𝚌𝚎̂ 𝚏𝚘𝚒 𝚍𝚎𝚜𝚊𝚏𝚒𝚊𝚍𝚘 𝚙𝚎𝚕𝚘 𝚃𝚛𝚎𝚒𝚗𝚊𝚍𝚘𝚛 𝙶𝚕𝚎𝚒𝚜𝚘𝚗!\n')
        
        pergunta = int(input('O que você deseja fazer?\n1. Batalhar | 2. Fugir\n'))
        
        if pergunta == 1:
            limpar_tela()
            escolher_pokemon()
            
        elif pergunta == 2:
            fugir()
            
        else:
            decisao()
            
    except ValueError:
        print('Entrada inválida. Por favor, digite um número.\n')
        decisao()
        

def escolher_pokemon():
    try:
        escolha_trio = int(input(f'𝚀𝚄𝙰𝙻 𝚃𝚁𝙸𝙾 𝙿𝙾𝙺𝙴𝙼𝙾𝙽 𝚅𝙾𝙲𝙴̂ 𝙴𝚂𝙲𝙾𝙻𝙷𝙴?\n\n𝚃𝚁𝙸𝙾 𝟷: {", ".join(str(pokemon) for pokemon in listaPokemonJogador1)}\n𝚃𝚁𝙸𝙾 𝟸: {", ".join(str(pokemon) for pokemon in listaPokemonJogador2)}'))

        if escolha_trio == 1:
            limpar_tela()
            print('Você escolheu o primeiro trio!')
            pokemon_escolhido1 = int(input(f'𝚀𝚄𝙰𝙻 𝙿𝙾𝙺𝙴𝙼𝙾𝙽 𝚂𝙴𝚁𝙰́ 𝙾 𝙿𝚁𝙸𝙼𝙴𝙸𝚁𝙾?\n1. 🍀 CHIKORITA \n2. 🔥 CYNDAQUILL \n3. 💧 TOTODILE\n'))

            if pokemon_escolhido1 in [1, 2, 3]:
                pokemon_escolhido = listaPokemonJogador1[pokemon_escolhido1 - 1]
                limpar_tela()
                print(f'VOCÊ LANÇOU {pokemon_escolhido.nome}!')
                start = batalhar(pokemon_escolhido, listaPokemonJogador1)
                if start:
                    return 

        elif escolha_trio == 2:
            limpar_tela()
            print('Você escolheu o segundo trio!')
            pokemon_escolhido2 = int(input(f'QUAL POKEMON SERÁ O PRIMEIRO?\n1. 🍀 TREECKO \n2. 🔥 TORCHIC \n3. 💧 MUDKIP\n'))

            if pokemon_escolhido2 in [1, 2, 3]:
                pokemon_escolhido = listaPokemonJogador2[pokemon_escolhido2 - 1]
                limpar_tela()
                print(f'VOCÊ LANÇOU {pokemon_escolhido.nome}!')
                start = batalhar(pokemon_escolhido, listaPokemonJogador2)
                if start:
                    return  

        print('Escolha inválida. Tente novamente.\n')
        escolher_pokemon()

    except ValueError:
        print('Entrada inválida. Por favor, digite um número.\n')
        escolher_pokemon()