import os
import random
from super_efetivo import *
from listaPokemon import *
from pokemon_db import *
from escolher import *
from batalha import *

# Função para limpar a tela
def limpar_tela():
    os.system('cls') 


def batalhar(pokemon_jogador, lista_pokemon_jogador):
    

    if len(listaPokemonsOponente) == 0:
        print("O oponente não tem mais Pokémon para batalhar!")
        print("Você venceu!")
        print("FIM DA BATALHA.")
        return True  # Indica que o jogo terminou

    # Iniciamos com o primeiro Pokémon do oponente
    oponente = listaPokemonsOponente[0]
    print(f'BATALHA POKEMON!')
    print(f'O seu Pokémon: {pokemon_jogador.nome} (HP: {pokemon_jogador.hp})')
    print(f'O oponente {oponente.nome}! (HP: {oponente.hp})')

    while pokemon_jogador.hp > 0 and len(listaPokemonsOponente) > 0:
        
        print(f'\nEscolha uma ação para {pokemon_jogador.nome}:')
        for i, ataque in enumerate(pokemon_jogador.ataque, 1):
            print(f'{i}. {ataque.nome}')  
        print(f'5. Usar item da mochila')  
        print(f'6. Trocar Pokémon')  

        try:
            escolha = int(input(f'\nEscolha uma ação (1-{len(pokemon_jogador.ataque)} ou 5 para usar item ou 6 para trocar Pokémon): '))
            limpar_tela()

            if escolha == 5:  
                mochila(pokemon_jogador)
                

            elif escolha == 6:  
                pokemon_jogador = escolher_novo_pokemon(pokemon_jogador, lista_pokemon_jogador)  
                if pokemon_jogador is None:  
                    continue

            elif 1 <= escolha <= len(pokemon_jogador.ataque):
                ataque_selecionado = pokemon_jogador.ataque[escolha - 1]
                print(f'{pokemon_jogador.nome} usou {ataque_selecionado.nome}!')

                dano = calcular_dano(ataque_selecionado, pokemon_jogador, listaPokemonsOponente[0])
                
                print(f'{pokemon_jogador.nome} causou {dano} de dano ao oponente!')

                
                oponente.hp -= dano
                if oponente.hp < 0:
                    oponente.hp = 0 

                print(f'O oponente agora tem {oponente.hp} HP!\n')

                
                if oponente.hp == 0:
                    print(f'Você derrotou {oponente.nome}!')
                    listaPokemonsOponente.pop(0)
                    if len(listaPokemonsOponente) > 0:
                        oponente = listaPokemonsOponente[0]
                        print(f'O oponente agora enviou {oponente.nome}! (HP: {oponente.hp})')
                    else:
                        print("O oponente não tem mais Pokémon!")
                        print("VITÓRIA!")
                        print("FIM DA BATALHA.")
                        exit()
                        return True

                
                if len(listaPokemonsOponente) > 0:
                    ataque_oponente = random.choice(oponente.ataque)
                    print(f'O oponente {oponente.nome} usou {ataque_oponente.nome}!')
                    dano_oponente = ataque_oponente.dano
                    pokemon_jogador.hp -= dano_oponente
                    if pokemon_jogador.hp < 0:
                        pokemon_jogador.hp = 0  

                    print(f'O seu Pokémon agora tem {pokemon_jogador.hp} HP!')

                    
                if pokemon_jogador.hp == 0:
                    print(f'{pokemon_jogador.nome} foi derrotado!')
                    pokemon_jogador = escolher_novo_pokemon(pokemon_jogador, lista_pokemon_jogador)
                    if pokemon_jogador is None:
                        limpar_tela()
                        print("DERROTA!")
                        print("FIM DA BATALHA.")
                        exit()
                        return True 
                    
                    else:
                        print(f'{pokemon_jogador.nome} foi escolhido para continuar a batalha!')

            else:
                print('Opção inválida. Tente novamente.')

        except (ValueError, IndexError):
            limpar_tela()
            print('Opção inválida. Tente novamente.')

    
    print("FIM DA BATALHA.") 
  


def escolher_novo_pokemon(pokemon_atual, lista_pokemon_jogador):
    print("\nEscolha um novo Pokémon para batalhar:")

    
    for idx, pokemon in enumerate(lista_pokemon_jogador, 1):
        if pokemon != pokemon_atual and pokemon.hp > 0:  
            print(f"{idx}. {pokemon.nome} (HP: {pokemon.hp})")

    print("0. Voltar")

    try:
        escolha = int(input("Escolha o número do Pokémon: "))

        if escolha == 0:
            return None 
        
        if 1 <= escolha <= len(lista_pokemon_jogador):
            limpar_tela()
            pokemon_novo = lista_pokemon_jogador[escolha - 1]
            if pokemon_novo.hp > 0:  
                print(f'Você trocou para {pokemon_novo.nome}!')
                return pokemon_novo  
            else:
                print("Esse Pokémon está derrotado! Escolha outro.")
                return escolher_novo_pokemon(pokemon_atual, lista_pokemon_jogador) 

        else:
            print("Escolha inválida! Tente novamente.")
            return escolher_novo_pokemon(pokemon_atual, lista_pokemon_jogador)

    except ValueError:
        print("Entrada inválida! Por favor, digite um número.")
        return escolher_novo_pokemon(pokemon_atual, lista_pokemon_jogador)  


class Item:
    def __init__(self, nome, cura):
        self.nome = nome
        self.cura = cura

    def usar(self, pokemon):
        pokemon.hp += self.cura
        print(f'{pokemon.nome} usou {self.nome} e recuperou {self.cura} HP!')

pocao = Item('Poção', 10)
super_pocao = Item('Super Poção', 20)

mochila_itens = [pocao, super_pocao]  

def mochila(pokemon):
    if len(mochila_itens) == 0:
        print("Sua mochila está vazia!")
        return

    print("\nMochila:")
    for idx, item in enumerate(mochila_itens, 1):
        print(f"{idx}. {item.nome} (+{item.cura} HP)")

    print("3. Voltar")

    try:
        escolha = int(input("Escolha um item para usar: "))
        limpar_tela()

        if escolha == 3:
            print("Voltando...")
            return
        
        if 1 <= escolha <= len(mochila_itens):
            item_escolhido = mochila_itens[escolha - 1]
            item_escolhido.usar(pokemon)  
            mochila_itens.remove(item_escolhido) 
        else:
            print("Escolha inválida!")

    except ValueError:
        limpar_tela()
        print("Entrada inválida! Por favor, digite um número.")
