from pokemon_db import *
import json

#Times possíveis para o jogador
listaPokemonJogador1 = []
listaPokemonJogador2 = []

#Time do oponente
listaPokemonsOponente = []

#Trio do oponente
bulbasaur = Pokemon(
    id_pokemon = 1,
    nome = "Bulbasaur",
    hp = 92, 
    ataques = [ChicotesDeVinha, FolhasDeNavalha, Mordida, Investida],
    velocidade = 45,
    tipo = "Planta",
    regiao = "Kanto"
)

charmander = Pokemon(
    id_pokemon = 2,
    nome = "Charmander",
    hp = 97,
    ataques = [PresasDeFogo, LancaChamas, Mordida, Investida],
    velocidade = 49,
    tipo = "Fogo",
    regiao = "Kanto"
)

squirtle = Pokemon(
    id_pokemon = 3,
    nome = "Squirtle",
    hp = 94,
    ataques = [RajadaDeBolhas, JatoDeAgua, Mordida, Investida],
    velocidade = 42,
    tipo = "Água",
    regiao = "Kanto"
)


listaPokemonsOponente.append(bulbasaur)
listaPokemonsOponente.append(charmander)
listaPokemonsOponente.append(squirtle)

#Pokemons primeiro trio jogador
chikorita = Pokemon(
    id_pokemon = 4,
    nome = "Chikorita",
    hp = 92,
    ataques = [BalaDeSemente, SementeSanguessuga, Mordida, Investida],
    velocidade = 45,
    tipo = "Planta",
    regiao = "Kanto"
)

cyndaquill = Pokemon(
    id_pokemon = 5,
    nome = "Cyndaquill",
    hp = 89,
    ataques = [Brasa, CargaDeChamas, Mordida, Investida],
    velocidade = 44,
    tipo = "Fogo",
    regiao = "Kanto"
)

totodile = Pokemon(
    id_pokemon = 6,
    nome = "Totodile",
    hp = 91,
    ataques = [PulsoDeAgua, JatoDeAgua, Mordida, Investida],
    velocidade = 43,
    tipo = "Água",
    regiao = "Kanto"
)


listaPokemonJogador1.append(chikorita)
listaPokemonJogador1.append(cyndaquill)
listaPokemonJogador1.append(totodile)

#Pokemons segundo trio jogador
treecko = Pokemon(
    id_pokemon = 7,
    nome = "Treecko",
    hp = 90,
    ataques = [BalaDeSemente, CorteDeVinha, Mordida, Investida],
    velocidade = 47,
    tipo = "Planta",
    regiao = "Kanto"
)

torchic = Pokemon(
    id_pokemon = 8,
    nome = "Torchic",
    hp = 88,
    ataques = [Brasa, PunhoDeFogo, Mordida, Investida],
    velocidade = 44,
    tipo = "Fogo",
    regiao = "Kanto"
)
                           
mudkip = Pokemon(
    id_pokemon = 9,
    nome = "Mudkip",
    hp = 93,
    ataques = [PulsoDeAgua, TiroDeAgua, Mordida, Investida],
    velocidade = 43,
    tipo = "Água",
    regiao = "Kanto"
)


listaPokemonJogador2.append(treecko)
listaPokemonJogador2.append(torchic)
listaPokemonJogador2.append(mudkip)


# Lista de movimentos
moves_list = ['Presa de Fogo', 'Lança Chamas', 'Mordida', 'Investida']
moves_list3 = ['Rajada de Bolhas', 'Jato de Água', 'Mordida', 'Investida']
moves_list4 = ['Bala de Semente', 'Semente Sanguessuga', 'Mordida', 'Investida']
moves_list5 = ['Brasa', 'Carga de Chamas', 'Mordida', 'Investida']
moves_list6 = ['Pulso de Água', 'Jato de Água', 'Mordida', 'Investida']
moves_list7 = ['Bala de Semente', 'Corte de Vinha', 'Mordida', 'Investida']
moves_list8 = ['Brasa', 'Punho de Fogo', 'Mordida', 'Investida']
moves_list9 = ['Pulso de Água', 'Tiro de Água', 'Mordida', 'Investida']



# Convertendo a lista para uma string JSON
serialized_moves = json.dumps(moves_list)

# Agora você pode salvar o `serialized_moves` no banco de dados (em vez da lista)
pokemon = Pokemon(id_pokemon= 2, hp=97, ataques=serialized_moves, velocidade=49, tipo='Fogo', nome='Charmander', regiao='Kanto')
session.add(pokemon)
session.commit()
