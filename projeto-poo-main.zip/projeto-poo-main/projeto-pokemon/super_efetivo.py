
from listaPokemon import *
from pokemon_db import *
from escolher import *
from batalha import *

    #ÀGUA ---> FOGO
    #FOGO ---> PLANTA
    #PLANTA ---> AGUA


tipo_eficaz = {
    'Água': 'Fogo',  
    'Fogo': 'Planta',  
    'Planta': 'Água' 
}


tipo_ineficaz = {
    'Água': 'Planta',  
    'Fogo': 'Água',    
    'Planta': 'Fogo'   
}

def calcular_dano(ataque, atacante, defensor):
    dano = ataque.dano  

    
    if tipo_eficaz.get(ataque.tipo) == defensor.tipo:
        print(f"Super eficaz! {ataque.tipo} é eficaz contra {defensor.tipo}.\n")
        dano *= 1.3  

    
    elif atacante.tipo == defensor.tipo:
        print(f"Os tipos são iguais! Dano neutro.\n")
        dano *= 1.0  

    
    elif tipo_ineficaz.get(ataque.tipo) == defensor.tipo:
        print(f"Pouco efetivo! {ataque.tipo} é ineficaz contra {defensor.tipo}.\n")
        dano *= 0.75  

   
    else:
        print(f"Ataque normal! {ataque.tipo} contra {defensor.tipo}.\n")
        dano *= 1.0  

    return dano